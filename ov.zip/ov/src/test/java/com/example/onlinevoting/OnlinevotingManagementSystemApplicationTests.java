package com.example.onlinevoting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinevotingManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}
 
}
