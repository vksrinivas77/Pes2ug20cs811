package com.example.onlinevoting;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinevotingManagementSystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(OnlinevotingManagementSystemApplication.class, args);
	}
}
